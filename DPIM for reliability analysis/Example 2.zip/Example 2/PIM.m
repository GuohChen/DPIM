function [disp,velp,accp]=PIM(M,K,C,dt,maxt,P,n,acc)
I=eye(n);
Z=zeros(n);
A=[Z,I;-M\K,-M\C];
G=[zeros(n,1);P];

iiA=inv(A);
% Solving exp(A,t)
EXPDT=EXPHDT(A,dt);
zeroq=zeros(n,maxt/dt);
disp=zeroq;
velp=zeroq;

zerop=zeros(n,1);
dispt=zerop;
velpt=zerop;
UK=[dispt;velpt];
accp(:,1)=P*acc(1);

for i=1:maxt/dt
    r1=G*(acc(i));
    r2=G*(acc(i+1)-acc(i))/dt;
    UK1=EXPDT*(UK+iiA*(r1+iiA*r2))-iiA*(r1+r2*dt+iiA*r2);
    disp(:,i+1)=UK1(1:n,:);
    velp(:,i+1)=UK1(n+1:2*n,:);
    accp(:,i+1)=M\(P*acc(i+1)-C*velp(:,i+1)-K*disp(:,i+1));
    UK=UK1;
end
end
