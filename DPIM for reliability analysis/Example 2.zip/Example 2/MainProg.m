clear; clc;
%% Example: plate with SCSF boundary condition
a=6; b=6;  h=0.12;        % length ,width and thickness  of the plate 
rho=2400;  kese=0.05;     % Density and damping ratio
E=36.2E9;  nu=0.2;        % Yong's modula and Poission's ratio
D=E*h^3/(12*(1-nu^2));    % Bending stiffness

wa=0;  wb=25*2*pi;        % Frequency band
%% ============Read Modal Data of the plate==========================
[ w, W, P ] =  ReadModalData;
nf=length(w);
%% ==========Discretization of frequency domain======================
nw=500;                                  % Ƶ�ʵȷ���
Nw=nw+1;                                 % Ƶ�ʵȷֺ󣬽ڵ���
dw=(wb-wa)/nw;
ww=wa:dw:wb;
%% ==============Random vibration analysis===========================
% Discretizing time domain
tmax=40;
% ʱ����
dt=0.02;
t=[0:dt:tmax]';
%% ==================================================================
M=eye(length(w));
C=2*kese*diag(w);
K=diag(w.^2);
%% =================DPIM for ranodm vibration analysis===============
Num_var=1;
Unif_var=1;    % Umiformly distributed random variable

Num_point=800; % Number of Itegral Points 

%% Representative point set
[ z, Pq, GFD ] = PointSet( Num_point);
p=size(z,2);

N_mid_node = 6;    % The point at middle of free edge of the plate
W_mt=zeros(Num_point,length(t));

% Generate representative acceleration excitations
Acc = Excitation( t, z, dw, ww  );

% Solving physical equation by using Precise Integration Method (PIM)
tic
for i=1:Num_point
    [disp,velp,accp]=PIM(M,K,C,dt,tmax,P,length(w),Acc(:,i));
       
    W_wmt(i,:)=W(N_mid_node,:)*disp;
    W_vmt(i,:)=W(N_mid_node,:)*velp;
    W_amt(i,:)=W(N_mid_node,:)*accp;
end
toc

displ=W_wmt';
veloc=W_vmt';

%% Calculating the PDF of deflection by DPIM
[ t,x,PDF ] = CalResponsePDF_DPIM( Pq, displ, t );   

% Performance function
Threshold=0.08;

%% Calculating structural reliability 

% Performance function
g1=Threshold-(abs(displ));

[ t, x1, g1PDF ] = DPIM_AC( Pq,g1,t);
Ps_AC=sum(g1PDF*(x1(2)-x1(1)),2);
figure
set(gca,'Fontname','Times New Roman','FontSize',15);
hold on
plot(t,Ps_AC,'r.-','LineWidth',2)
axis([0 t(end) 0 1.2])
           
%% Plot PDF vurves obtained by DPIM
t1=1; t2=10; t3=15;  
It01=abs(t-t1);
It02=abs(t-t2);
It03=abs(t-t3);
t01=find(It01==min(min(It01)));
t02=find(It02==min(min(It02)));
t03=find(It03==min(min(It03)));

figure
hold on
plot(x,PDF(t01,:))
plot(x,PDF(t02,:))
plot(x,PDF(t03,:))
xlabel('Deflection (m)')
ylabel('PDF')
legend('t=1 s','t=10 s','t=15 s')
