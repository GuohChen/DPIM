function [T]=EXPHDT(A,dt)

N=20;
m=2^N;
t=dt/m;
I=eye(size(A));
Ta=A*t+(A*t)^2*(I+(A*t)/3+(A*t)^2/12)/2;

for i=1:20
  Ta=2*Ta+Ta^2;
end
T=I+Ta;