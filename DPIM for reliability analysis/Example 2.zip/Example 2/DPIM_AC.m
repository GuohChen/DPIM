function [t,x,Z ]  = DPIM_AC( Pq, g, t )
%DPIM �˴���ʾ�йش˺�����ժҪz
%   �˴���ʾ��ϸ˵��
Nx=2^12;
minimum=min(g(:)); maximum=max(g(:));
Range=maximum-minimum;
MIN=minimum-Range/10; MAX=maximum+Range/10;
R=MAX-MIN; dx=R/(Nx-1); x=MIN+[0:dx:R];

Pq1 = repmat(Pq,length(t),1);
for j=1:length(t)
    id1 = g(j,:)<=0;
    Pq1(j:end,id1) = 0;
end
    
Z = zeros(length(t),length(x));
sigma=0.9*min(std(g,[],2),iqr(g,2)/1.34)*(length(Pq))^(-1/5);
sigma(sigma<dx)=dx;
for i=1:size(Pq1,2)
    pp2 = Pq1(:,i).*normpdf(x,g(:,i),sigma);
    Z = Z+pp2;
end