function [t, x, rPDF ]  =  CalResponsePDF_DPIM( Pq, data, t )
%DPIM �˴���ʾ�йش˺�����ժҪz
%   �˴���ʾ��ϸ˵��

Nx=2^10;
minimum=min(data(:)); maximum=max(data(:));
Range=maximum-minimum;
MIN=minimum-Range/10; MAX=maximum+Range/10;
R=MAX-MIN; dx=R/(Nx-1); x=MIN+[0:dx:R];


sigma=0.9*min(std(data,[],2),iqr(data,2)/1.34)*(length(Pq))^(-1/5);

sigma(sigma==0)=1e-6;

rPDF = zeros(length(t),length(x));
for i=1:length(Pq)
    pp1 = Pq(i)*normpdf(x,data(:,i),sigma);
    rPDF = rPDF+pp1;
end
end

