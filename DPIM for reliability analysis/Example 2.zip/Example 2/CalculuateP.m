function [ P ] = CalculuateP(Load,W,f )
%CALCULUATEP �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
global a b c d q
global rho h
syms x y

nf=length(f);
I=zeros(nf,1);P=zeros(nf,1);
for j=1:length(f);
    switch Load
        case 1
            I(j)=eval(int(int(W(j),y,0,b),x,0,a));
            P(j)=-rho*h*I(j);
        case {2,3}
            P(j)=subs(W(j),[x,y],[c,d]);
        case {4,5}
            P(j)=int(int(@(x,y) W(j)*q,y,0,b),x,0,a);
            %         case 6
            %             P(:,:,j)=int(int(@(x,y) W(j)*q,y,0,b),x,0,a);
            %     end
            
    end
    P=double(P);
end

