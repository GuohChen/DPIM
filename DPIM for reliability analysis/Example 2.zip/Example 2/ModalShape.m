function [Wx,Wy,W]=ModalShape(j,a,b,nu,sOmg,sT,sR,sgs)
global x y BC
syms x y
Omgj=sOmg(j); Tj=sT(j); Rj=sR(j);sgsj=sgs(j);
Lmdj=sqrt(Rj^2+Tj^2); Zj=sqrt(Rj^2+Omgj^2);

switch BC
    case 1
        A=0; B=1; C=0; D=0;
        E=0; F=1; G=0; H=0;
    case 2
        A=0; B=1; C=0; D=0;
        E=0; F=1; G=0; H=-sin(Tj*b)/sinh(Zj*b);
    case 4
        A=0; B=1; C=0; D=0;
        gm=(Zj)/(Tj); Xi=(cos(Tj*b)-cosh(Zj*b))/(gm*sin(Tj*b)-sinh(Zj*b));
        E=-1; F=gm*Xi; G=1; H=-Xi;
    case 5
        A=0; B=1; C=0; D=-sin(Omgj*a)/sinh(Lmdj*a);
        E=0; F=1; G=0; H=-sin(Tj*b)/sinh(Zj*b);
    case 6
        A=0; B=1; C=0; D=-sin(Omgj*a)/sinh(Lmdj*a);
        gm=(Zj)/(Tj); Xi=(cos(Tj*b)-cosh(Zj*b))/(gm*sin(Tj*b)-sinh(Zj*b));
        E=-1; F=gm*Xi; G=1; H=-Xi;
    case 7
        gm=(Lmdj)/(Omgj); 
        Xi=(cos(Omgj*a)-cosh(Lmdj*a))/(gm*sin(Omgj*a)-sinh(Lmdj*a));
        A=-1; B=gm*Xi; C=1; D=-Xi;
        gm=(Zj)/(Tj); Xi=(cos(Tj*b)-cosh(Zj*b))/(gm*sin(Tj*b)-sinh(Zj*b));
        E=-1; F=gm*Xi; G=1; H=-Xi;
    case 8
        gm=(Lmdj)/(Omgj); 
        Xi=(cos(Omgj*a)-cosh(Lmdj*a))/(gm*sin(Omgj*a)-sinh(Lmdj*a));
        A=-1; B=gm*Xi; C=1; D=-Xi;
        E=0; F=1; G=0; H=-sin(Tj*b)/sinh(Zj*b);
    case {3,9,10}
        af1=Tj^2+nu*Omgj^2; af2=Zj^2-nu*Omgj^2; 
        bt1=Tj*(Tj^2+(2-nu)*Omgj^2);
        bt2=Zj*(Zj^2-(2-nu)*Omgj^2);
        if BC==3
            A=0; B=1; C=0; D=0;
            E=0; F=1; G=0; H=(af1*sin(Tj*b))/(af2*sinh(Zj*b));
        end
        if BC==9
            A=0; B=1; C=0; D=0;
            k=(Zj)/(Tj); 
            gm=(af2*sinh(Zj*b)+k*af1*sin(Tj*b))/(af2*cosh(Zj*b)+af1*cos(Tj*b));
            E=gm; F=-k; G=-gm; H=1;
        end
        if BC==10
            A=0; B=1; C=0; D=0;
            if sgsj==1
                k1=cosh(Tj*b)-cosh(Zj*b);
                k2=(Omgj^2*nu-Tj^2)/(Zj^2-Omgj^2*nu);
                
                gm1=Zj*(Tj^2-Omgj^2*nu)*(Zj^2+Omgj^2*(nu-2));
                gm2=Tj*(Tj^2-Omgj^2*nu)*(Tj^2+Omgj^2*(nu-2));
                
                gf1=Tj*sinh(Zj*b)*(Tj^2+Omgj^2*(nu-2))*(Zj^2-Omgj^2*nu)-...
                    Zj*sinh(Tj*b)*(Tj^2-Omgj^2*nu)*(Zj^2+Omgj^2*(nu-2));
                gf2=Zj*sinh(Tj*b)*(Zj^2+Omgj^2*(nu-2))*(Tj^2-Omgj^2*nu)-...
                    Tj*sinh(Zj*b)*(Zj^2-Omgj^2*nu)*(Tj^2+Omgj^2*(nu-2));     
                
                E=1; F=gm1*k1/gf1; G=k2; H=gm2*k1/gf2;
            else
                k1=af2/af1; k2=bt2/bt1;
                gm=(-af1*k2*sin(Tj*b)+af2*sinh(Zj*b))/(-af2*cos(Tj*b)+af2*cosh(Zj*b));
                E=-k1*gm; F=k2; G=-gm; H=1;
            end
        end
end
% [s,t]=meshgrid(0:a/N:a, 0:b/N:b);
Wx=A*cos(Omgj*x)+B*sin(Omgj*x)+C*cosh(Lmdj*x)+D*sinh(Lmdj*x);  
if BC==10 && sgsj==1
    Wy=E*cosh(Tj*y)+F*sinh(Tj*y)+G*cosh(Zj*y)+H*sinh(Zj*y);
else
    Wy=E*cos(Tj*y)+F*sin(Tj*y)+G*cosh(Zj*y)+H*sinh(Zj*y);
end

W=Wx.*Wy;
% pr=max(max(abs(W))); W=W/pr;
% figure; surf(s,t,W);








