function [ z, Pq, GFD ] = PointSet(Num_point) 
%  
%  Point set for DPIM

z=dlmread(['Point set_',num2str(Num_point),'.txt']);
Pq=dlmread(['Integral weights of Point set_',num2str(Num_point),'.txt']);
GFD=dlmread(['GFD of Point set_',num2str(Num_point),'.txt']);
end

