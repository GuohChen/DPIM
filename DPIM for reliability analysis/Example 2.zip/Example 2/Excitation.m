function Acc = Excitation( t, zz, dw, ww )
% Generate fully nonstationary process 

dw1=dw;
ww1=ww;
Nw=length(ww);
p=size(zz,2);

%% Time modelated function
AA=4.0; p1=0.0995;
g=@(tt) AA*(exp(-p1*tt)-exp(-2*p1*tt));
   
%% PSD paramaters
S0=1; wh=0.5*pi; N=2;
G=ww.^(2*N)./(ww.^(2*N)+wh^(2*N));
w0=39.4; wn=4.86;     
wg= w0-(w0-wn)*t/t(end);
eg=0.64;
        
x0=(bsxfun(@ldivide,wg,ww)).^2;
x1=1+4*eg.^2.*x0;
x2=(1-x0).^2+4*eg.^2.*x0;
Sgw=(bsxfun(@times,G,x1))./x2*S0;

%% Generate representative acceletation excitations 
%  via Random function-based spectral representation

theta=zz(1,:)*2*pi;

Acc=zeros(length(t),p);
rand('state',0);
NN=randperm(Nw);
for j=1:p
    XX=sqrt(2)*cos((1:Nw)*(theta(j)+pi/4));  
    YY=sqrt(2)*sin((1:Nw)*(theta(j)+pi/4));
    X=XX(NN);
    Y=YY(NN);
    B=sqrt(Sgw*dw1).*(bsxfun(@times,cos(bsxfun(@times,t,ww1)),X)+bsxfun(@times,sin(bsxfun(@times,t,ww1)),Y));
    Ga=sum(B,2);
     
    % Representative acceleration excitations
    Acc(:,j)=g(t).*(Ga);
end





