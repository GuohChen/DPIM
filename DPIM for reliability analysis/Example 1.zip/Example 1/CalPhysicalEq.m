function [ k1,U ] = CalPhysicalEq( kk,z,F,n,cov )
% Input��
% kk  ���� Floor stiffness;
% F   ���� Force;
% z   ���� Integral point set;
% n   ���� Number of point set;

% Output��
% k1   ���� Representative floor stiffness;
% U   ���� Floor displacement;

for i=1:n
    k1(i,:)= kk(i)*(1+cov*z(i,:));
end

p=size(z,2);
U=zeros(n,p);
tic
for ip=1:p
    k=diag(k1(:,ip));
    for j=1:(n-1)
        K(j,j)=k(j,j)+k(j+1,j+1);
        K(j,j+1)=-k(j+1,j+1);
        K(j+1,j)=-k(j+1,j+1);
    end
    K(n,n)=k(n,n);
    
    U(:,ip)=K\F;
end
end

