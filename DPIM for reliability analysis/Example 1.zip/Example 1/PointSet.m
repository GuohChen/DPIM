function [ z, Pq, GFD ] = PointSet( Method, Num_point) 
%  Point set 1 for MCS
%  Point set 2 for DPIM

switch Method
    case 1
        z=dlmread(['Point set 1_',num2str(Num_point),'.txt']);
        Pq=dlmread(['Integral weights of Point set 1_',num2str(Num_point),'.txt']);
        GFD=dlmread(['GFD of Point set 1_',num2str(Num_point),'.txt']);
    case 2
        z=dlmread(['Point set 2_',num2str(Num_point),'.txt']);
        Pq=dlmread(['Integral weights of Point set 2_',num2str(Num_point),'.txt']);
        GFD=dlmread(['GFD of Point set 2_',num2str(Num_point),'.txt']);
end
end

