function [ x,rPDF ] = CalResponsePDF_DPIM( data,Pq )

Nx=2^10;
minimum=min(data); maximum=max(data);
Range=maximum-minimum;
MIN=minimum-Range/10; MAX=maximum+Range/10;
R=MAX-MIN; dx=R/(Nx-1); x=MIN+[0:dx:R];

% Smoothing parameter
sigma=0.9*min(std(data),iqr(data)/1.34)*(size(data,2))^(-1/5);
%           
rPDF = zeros(1,Nx);
for i=1:length(Pq)
    pp1 = Pq(i)*normpdf(x,data(i),sigma);
    rPDF = rPDF+pp1;
end

end

