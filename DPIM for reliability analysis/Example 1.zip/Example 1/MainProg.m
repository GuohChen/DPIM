clear; %clc;  %close all
%% Initializing random parameters
Num_var=5;         % Number of random variables
Num_point=1000;    % Number of integral (representative) points

%% Initializing structural parameters
n=5;
F=[0.5 1 1 1 0.5]'*1E6;
kk=[3.8 3.6 3.4 3.2*ones(1,n-4) 3.0]*1e8;
cov=0.2;

%% Step 1: Selection of integral points and weights
%  1-MCS�� 2-DPIM; 
Method=1;
[ z, Pq, GFD ] = PointSet( Method, Num_point);

%% Solving yhysical equation F, forming performance function G
tic
[k1, Dis] = CalPhysicalEq( kk,z,F,n,cov );

% Performance function
g=0.05-max(abs(Dis));
toc

%% Calculating the PDF of performance function by DPIM, MCS, QMCS
switch Method
    case 1
     [ x,PDF ] = CalResponsePDF_MCS( g, Pq );
    case 2
     [ x,PDF ] = CalResponsePDF_DPIM( g, Pq );   
end
%% Calculating structural reliability 
idx1=find(x<=0);
Pf=sum(PDF(idx1)*(x(2)-x(1)));
Pr=1-Pf

%% Plot Point set, PDF and CDF diagram
DiagramPlot( Method,k1,x,PDF)



