function DiagramPlot( Method,k1,x,PDF)

figure
set(gcf,'position',[100 100 550 500]);
hold on
box on
plot(k1(1,:),k1(4,:),'wo','MarkerSize',2.5,...
    'MarkerEdgeColor','r','LineWidth',1.1)
set(gca,'ylim',[1e8,6.5e8],'ytick',[1e8:1e8:6e8]);
set(gca,'xlim',[1e8,6.5e8],'xtick',[1e8:1e8:6e8]);
set(gca,'Fontname','Times New Roman','FontSize',15);
xlabel('\it \Theta_{\rm1} \rm(N/m)')
ylabel('\it \Theta_{\rm4} \rm(N/m)')

switch Method
    case 1
        figure(10)
        hold on
        title('PDF')
        set(gca,'Fontname','Times New Roman','FontSize',15);
        plot(x,PDF,'r-','LineWidth',1.5)
        
        figure(11)
        title('CDF')
        set(gca,'Fontname','Times New Roman','FontSize',15);
        semilogy(x,cumsum(PDF*(x(2)-x(1))),'r-','LineWidth',1.5)
        hold on
         
        figure(12)
        title('POE')
        set(gca,'Fontname','Times New Roman','FontSize',15);
        semilogy(x,1-cumsum(PDF*(x(2)-x(1))),'r-','LineWidth',1.5)
        hold on
    case 2
        figure(10)
        hold on
        title('PDF')
        set(gca,'Fontname','Times New Roman','FontSize',15);
        bar(x,PDF)
        
        figure(11)
        title('CDF')
        set(gca,'Fontname','Times New Roman','FontSize',15);
        semilogy(x,cumsum(PDF*(x(2)-x(1))),'g--','LineWidth',1.5)
        hold on
        
        figure(12)
        title('POE')
        set(gca,'Fontname','Times New Roman','FontSize',15);
        semilogy(x,1-cumsum(PDF*(x(2)-x(1))),'g-','LineWidth',1.5)
        hold on
    case 3
        figure(10)
        hold on
        title('PDF')
        set(gca,'Fontname','Times New Roman','FontSize',15);
        bar(x,PDF)
        
        figure(11)   
        title('CDF')
        set(gca,'Fontname','Times New Roman','FontSize',15);
        semilogy(x,cumsum(PDF*(x(2)-x(1))),'k-.','LineWidth',1.5)
        hold on
        
        figure(12)
        hold on
        title('POE')
        set(gca,'Fontname','Times New Roman','FontSize',15);
        semilogy(x,1-cumsum(PDF*(x(2)-x(1))),'k-.','LineWidth',1.5)
        hold on
end
end

