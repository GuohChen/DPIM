function [ x,rPDF ] = CalResponsePDF_MCS( data,Pq )

Nx=2^9;
minimum=min(data); maximum=max(data);
Range=maximum-minimum;
MIN=minimum-Range/10; MAX=maximum+Range/10;
R=MAX-MIN; dx=R/(Nx-1); x=MIN+[0:dx:R];
dx=x(2)-x(1);
UPDF=hist(data,x);         
rPDF=UPDF/length(data)/dx; 

end

